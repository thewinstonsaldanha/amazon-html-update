package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.Category;
import com.model.Status;

public class CategoryDAOImpl implements CategoryDAO {
	private static Connection con;

    static {
        try {
            Class.forName("org.h2.Driver");
            con = DriverManager.getConnection("jdbc:h2:~/test", "sa", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public CategoryDAOImpl() {
        con = DBUtil.getConnection();
        System.out.println("Category impl's connection= " + con.hashCode());
    }
	@Override
	public Status addCategory(Category category) throws SQLException {
		// TODO Auto-generated method stub
		 String sql = "INSERT INTO Category(categoryid, categoryname) VALUES (?, ?)";
	        PreparedStatement pst = con.prepareStatement(sql);
	        pst.setInt(1, category.getCategoryid());
	        pst.setString(2, category.getCategoryname());
	        
	        
	        int res = pst.executeUpdate();
	        
	        //pst.close(); // Close the PreparedStatement
	        
	        return new Status((res == 1)?true:false);
	}
	@Override
	public Status updateCategory(Category category) throws SQLException {
		// TODO Auto-generated method stub
		String sql = "UPDATE category SET categoryname = ? WHERE categoryid = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        
        pst.setString(1, category.getCategoryname());
        pst.setInt(2, category.getCategoryid());
        
        int res = pst.executeUpdate();
        
        // Close the PreparedStatement
        pst.close();
        
        return new Status ((res == 1)?true:false);
	}
	@Override
	public List<Category> getAllCategories() throws SQLException {
		// TODO Auto-generated method stub
		List<Category> categories = new ArrayList<>();
        String sql = "SELECT categoryid, categoryname FROM category";
        PreparedStatement pst = con.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        
        while (rs.next()) {
            int categoryId = rs.getInt("categoryid");
            String categoryName = rs.getString("categoryname");
            Category category = new Category(categoryId, categoryName);
            categories.add(category);
        }
        
        // Close the ResultSet and PreparedStatement
        rs.close();
        pst.close();
        
        return categories;
	}
	@Override
	public Status deleteCategory(int categoryId) throws SQLException {
		// TODO Auto-generated method stub
		
		String sql = "DELETE FROM category WHERE categoryid = ?";
        PreparedStatement pst = con.prepareStatement(sql);
        
        pst.setInt(1, categoryId);
        int res = pst.executeUpdate();
        
        // Close the PreparedStatement
        pst.close();
        
        return new Status((res == 1)?true:false);
	}
	
	
	
	
	
	
	
	}
	
	
	
      

